using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using api.models;
using System.Collections.Generic;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecipeController : ControllerBase
    {

        //This initializes the connection string variable, which will then be filled with the connection string itself from the connection string class.
        private string connectionString;
        
        public RecipeController()
        {
            //As mentioned, the connection string class is used to fill a variable, and a table is then created at the connected database.
            var connString = new ConnectionString();
            connectionString = connString.cs;
            CreateRecipesTable();
        }

        private void CreateRecipesTable()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                //If the table does not already exist, this inserts one into MySQL with all the necessary attributes.
                string createTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Recipes (
                        Id INT AUTO_INCREMENT PRIMARY KEY,
                        Name VARCHAR(255) NOT NULL,
                        Rating INT NOT NULL,
                        DateEntered DATETIME NOT NULL,
                        Favorited BOOLEAN NOT NULL,
                        Deleted BOOLEAN NOT NULL
                    );";

                MySqlCommand command = new MySqlCommand(createTableQuery, connection);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        [HttpGet]
        public IEnumerable<Recipe> Get()
        {
            //TAll data that is not soft deleted (i.e. wherein deleted = 0) is put onto a list instead of an array.
            //
            var recipes = new List<Recipe>();

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlCommand command = new MySqlCommand("SELECT * FROM Recipes WHERE Deleted = 0", connection);
                connection.Open();
                MySqlDataReader reader = command.ExecuteReader();

while (reader.Read())
{
    //This while loop retrieves data from the SQL table creates objects and then populates a list of those objects from said table.
    recipes.Add(new Recipe
    {
        recipeId = reader.GetInt32("Id"),
        recipeName = reader.GetString("Name"),
        recipeRating = reader.GetInt32("Rating"),
        recipeDateEntered = reader.GetDateTime("DateEntered"),
        IsFavorited = reader.GetBoolean("Favorited"),
        IsDeleted = reader.GetBoolean("Deleted")
    });
}
            }

            return recipes;
        }

        [HttpGet("{id}")]
        public ActionResult<Recipe> Get(int id)
        {
            //This retrieves a recipe in regards to its recipeID from the MySQL. Theres some error checking aswell.
            Recipe recipe = null;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlCommand command = new MySqlCommand("SELECT * FROM Recipes WHERE Id = @Id AND Deleted = 0", connection);
                command.Parameters.AddWithValue("@Id", id);
                connection.Open();
                MySqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    recipe = new Recipe
                    {
                        recipeId = reader.GetInt32("Id"),
                        recipeName = reader.GetString("Name"),
                        recipeRating = reader.GetInt32("Rating"),
                        recipeDateEntered = reader.GetDateTime("DateEntered"),
                        IsFavorited = reader.GetBoolean("Favorited"),
                        IsDeleted = reader.GetBoolean("Deleted")
                    };
                }
            }
            return recipe;
        }

        [HttpPost]
        public IActionResult Post([FromBody] Recipe recipe)
        {
//This creates a new recipe within the MySql. It inserts the command, executes it, and retrieves the ID.
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlCommand command = new MySqlCommand(
                    "INSERT INTO Recipes (Name, Rating, DateEntered, Favorited, Deleted) VALUES (@Name, @Rating, @DateEntered, @Favorited, @Deleted); SELECT LAST_INSERT_ID();",
                    connection);
                command.Parameters.AddWithValue("@Name", recipe.recipeName);
                command.Parameters.AddWithValue("@Rating", recipe.recipeRating);
                command.Parameters.AddWithValue("@DateEntered", recipe.recipeDateEntered);
                command.Parameters.AddWithValue("@Favorited", recipe.IsFavorited);
                command.Parameters.AddWithValue("@Deleted", recipe.IsDeleted);

                connection.Open();
                recipe.recipeId = Convert.ToInt32(command.ExecuteScalar());
                //This is another holdover from naming misconventions wherein I had some as recipeID some as ID and some as recipeID. I couldn't figure out how to change this so it stayed because it works.
                return CreatedAtAction(nameof(Get), new { id = recipe.recipeId }, recipe);
            }
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Recipe updatedRecipe)
        {
            //This updates existing recipes!
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlCommand command = new MySqlCommand(
                    "UPDATE Recipes SET Name = @Name, Rating = @Rating, DateEntered = @DateEntered, Favorited = @Favorited, Deleted = @Deleted WHERE Id = @Id",
                    connection);
                command.Parameters.AddWithValue("@Id", id);
                command.Parameters.AddWithValue("@Name", updatedRecipe.recipeName);
                command.Parameters.AddWithValue("@Rating", updatedRecipe.recipeRating);
                command.Parameters.AddWithValue("@DateEntered", updatedRecipe.recipeDateEntered);
                command.Parameters.AddWithValue("@Favorited", updatedRecipe.IsFavorited);
                command.Parameters.AddWithValue("@Deleted", updatedRecipe.IsDeleted);

                connection.Open();

            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            //This soft deletes recipes.
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                MySqlCommand command = new MySqlCommand(
                    "UPDATE Recipes SET Deleted = 1 WHERE Id = @Id",
                    connection);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
            }

            return NoContent();
        }
    }
}
