using System;
//simple class that has the connection string to my JawsDB Database.
namespace api{
        public class ConnectionString
    {
        public string cs {get; set;}

        public ConnectionString(){
            string server = "xq7t6tasopo9xxbs.cbetxkdyhwsb.us-east-1.rds.amazonaws.com";
            string database = "iwar33yobc98tku0";
            string port ="3306";
            string userName = "plvd1bcni8mz2uv1";
            string password = "az9ocp8vgo9qe7de";

            cs = $@"server = {server};user={userName};database={database};port={port};password={password};";
        }
    }
}