let app = document.getElementById("app");
let recipes = [];

// Fetch recipes from the API
async function fetchRecipes() {
    const response = await fetch('http://localhost:5000/api/recipe');
    if (response.ok) {
        recipes = await response.json();

        // Ensure RecipeId is set correctly
        recipes.forEach(recipe => {
            // Log the original recipeId
            console.log("Original Recipe ID from API:", recipe.recipeId);
            recipe.RecipeId = recipe.recipeId; // Adjust this based on your actual response
            // Log the new RecipeId
            console.log("New RecipeId set:", recipe.RecipeId);
        });

        // Log fetched recipes for debugging
        console.log("Fetched Recipes:", recipes);
    } else {
        console.error("Failed to fetch recipes:", response.statusText);
    }
}

// Handle page load
function handleOnLoad() {
    fetchRecipes().then(() => {
        createTable();
        createForm();
    });
}

// Create the form for adding recipes
function createForm() {
    let oldForm = document.getElementById('recipeForm');
    if (oldForm) {
        oldForm.remove();
    }

    // Create a simple form
    let recipeForm = document.createElement('form');
    recipeForm.id = "recipeForm";

    let recipeInput = document.createElement('input');
    recipeInput.type = 'text';
    recipeInput.placeholder = 'Please enter a recipe name!';
    recipeInput.id = 'newRecipe';
    recipeForm.appendChild(recipeInput);

    let ratingInput = document.createElement('input');
    ratingInput.type = 'text';
    ratingInput.placeholder = 'Please enter a rating!';
    ratingInput.id = 'newRating';
    recipeForm.appendChild(ratingInput);

    let submitButton = document.createElement('button');
    submitButton.textContent = 'Submit';
    recipeForm.appendChild(submitButton);

    // Add event listener for form submission
    recipeForm.addEventListener('submit', async function (e) {
        e.preventDefault();
    
        let currentDate = new Date();
        let formattedDate = currentDate.toISOString().split('T')[0]; // Use currentDate here
    
        let recipe = {
            recipeName: e.target.elements.newRecipe.value,
            recipeRating: e.target.elements.newRating.value,
            recipeDateEntered: formattedDate, // Use the formatted date here
            isFavorited: false,
            isDeleted: false
        };
    
        const response = await fetch('http://localhost:5000/api/recipe', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(recipe)
        });
    
        if (response.ok) {
            const newRecipe = await response.json();
            
            // Log the response to check if recipeId is present
            console.log("New Recipe Response:", newRecipe);
            
            // Ensure the new recipe has a recipeId
            if (newRecipe.recipeId) {
                newRecipe.RecipeId = newRecipe.recipeId; // Assign the recipeId correctly
                recipes.push(newRecipe); // Update local recipes array with the new recipe
                addRow(newRecipe);
                refreshTable();
            } else {
                console.error("New recipe does not have a recipeId:", newRecipe);
            }
        } else {
            console.error("Failed to add recipe:", response.statusText);
        }
    });

    app.appendChild(recipeForm);
}

// Add a row to the recipe table
function addRow(recipe) {
    console.log("Adding Recipe ID:", recipe.RecipeId); // Debugging line
    let tableBody = document.getElementById('recipeTableBody');
    let tr = document.createElement('TR');
    tableBody.appendChild(tr);

    let td1 = document.createElement('TD');
    td1.width = 200;
    td1.appendChild(document.createTextNode(recipe.recipeName));
    tr.appendChild(td1);

    let td2 = document.createElement('TD');
    td2.width = 60;
    td2.appendChild(document.createTextNode(recipe.recipeRating));
    tr.appendChild(td2);

    let td3 = document.createElement('TD');
    td3.width = 120;

    // Format the date for display
    let formattedDate = new Date(recipe.recipeDateEntered).toLocaleDateString();
    td3.appendChild(document.createTextNode(formattedDate)); // Use the formatted date here
    tr.appendChild(td3);

    let td4 = document.createElement('TD');
    td4.width = 120;
    td4.appendChild(document.createTextNode(recipe.isFavorited.toString()));
    tr.appendChild(td4);

    let td5 = document.createElement('TD');
    td5.width = 120;

    // Create buttons for favorite and delete actions
    let favoriteButton = document.createElement('button');
    favoriteButton.textContent = recipe.isFavorited ? 'Unfavorite' : 'Favorite';
    td5.appendChild(favoriteButton);

    let deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    td5.appendChild(deleteButton);

    // Add event listeners for buttons
    favoriteButton.addEventListener('click', async function () {
        console.log("Updating Recipe ID:", recipe.RecipeId); // Check the ID before PUT
        if (!recipe.RecipeId) {
            console.error("Recipe ID is undefined! Cannot update favorite status.");
            return; // Exit if RecipeId is undefined
        }
        recipe.isFavorited = !recipe.isFavorited; // Toggle favorite status

        const response = await fetch(`http://localhost:5000/api/recipe/${recipe.RecipeId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(recipe)
        });

        if (response.ok) {
            localStorage.setItem('myRecipes', JSON.stringify(recipes));
            refreshTable();
        } else {
            console.error("Failed to update favorite status:", response.statusText);
        }
    });

    deleteButton.addEventListener('click', async function () {
        if (!recipe.RecipeId) {
            console.error("Recipe ID is undefined! Cannot delete recipe.");
            return; // Exit if RecipeId is undefined
        }
        const response = await fetch(`http://localhost:5000/api/recipe/${recipe.RecipeId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            recipe.isDeleted = true; // Update the local recipe status
            localStorage.setItem('myRecipes', JSON.stringify(recipes));
            refreshTable();
        } else {
            console.error("Failed to delete recipe:", response.statusText);
        }
    });

    tr.appendChild(td5);
}

// Create the recipe table
function createTable() {
    let oldTable = document.getElementById('recipeTable');
    if (oldTable) {
        oldTable.remove();
    }

    let table = document.createElement('TABLE');
    table.border = '1';
    table.id = 'recipeTable';
    let tableBody = document.createElement('TBODY');
    tableBody.id = 'recipeTableBody';
    table.appendChild(tableBody);

    let tr = document.createElement('TR');
    tableBody.appendChild(tr);

    let th1 = document.createElement('TH');
    th1.width = 200;
    th1.appendChild(document.createTextNode('Recipe'));
    tr.appendChild(th1);

    let th2 = document.createElement('TH');
    th2.width = 60;
    th2.appendChild(document.createTextNode('Rating'));
    tr.appendChild(th2);

    let th3 = document.createElement('TH');
    th3.width = 120;
    th3.appendChild(document.createTextNode('Date Entered'));
    tr.appendChild(th3);

    let th4 = document.createElement('TH');
    th4.width = 120;
    th4.appendChild(document.createTextNode('Is Favorited'));
    tr.appendChild(th4);

    let th5 = document.createElement('TH');
    th5.width = 120;
    th5.appendChild(document.createTextNode('Actions'));
    tr.appendChild(th5);

    app.appendChild(table);

    // Filter out deleted recipes and sort by rating
    recipes
        .filter(recipe => !recipe.isDeleted)
        .sort((a, b) => parseFloat(b.recipeRating) - parseFloat(a.recipeRating)) // Updated to match C# model
        .forEach((recipe) => {
            addRow(recipe);
        });
}

// Refresh the table and form
function refreshTable() {
    createTable();
    createForm();
}

// Initial load
handleOnLoad();
