namespace api.models
{
    public class Recipe
    {
        public int recipeId { get; set; } 
        public string recipeName { get; set; }
        public int recipeRating { get; set; }
        public DateTime recipeDateEntered { get; set; }
        public bool IsFavorited { get; set; }
        public bool IsDeleted { get; set; }
    }
}
