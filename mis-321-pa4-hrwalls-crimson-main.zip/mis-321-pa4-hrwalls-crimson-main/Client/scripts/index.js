let app = document.getElementById("app");
//I initially had the recipes as a locally stored JSON thing, but since I have backend attachment through MySQL, I know just initialize the array so that I can fill it later.
let recipes = [];

//This should, in theory, fetch recipes from the API. I don't know if ive fundamentally misunderstood the assignment, and im still trying to trouble shoot it.
//It appears I need to have both the live server from vscode, as well as the dotnet watch run running at the same time.
async function fetchRecipes() {
    const response = await fetch('http://localhost:5000/api/recipe');
    //I kept on getting 400 and 404 errors. I tried my best to trouble shoot and do a bunch of console logs (which I mainly removed) but these had to end up staying.
    //I think it has somethign to do with null values being unnacceptable when alot more code relies on them, so these are functionally necessary, unfortunately. 
    //I think if I had better coding I would be able to get rid of these but they're like that one coconut.jpg in TF2.
    if (response.ok) {
        recipes = await response.json();

        recipes.forEach(recipe => {
            recipe.RecipeId = recipe.recipeId; // Adjust this based on your actual response
        });
    } else {
        console.error("Failed to fetch recipes:", response.statusText);
    }
}

//This, along with the refresh later, fixed an html/js problem wherein my form would appear above the table when it refreshed with new data within it. Since it creates a new one in order they stay in order whenever handleonload or refresh table are called.
function handleOnLoad() {
    fetchRecipes().then(() => {
        createTable();
        createForm();
    });
}
//This is mostly self explanatory. There were some issues with the C# object naming conventions not meshing well with my JS naming, I think, so I added a bunch of responses and console errors to show me what was going wrong.
//They were pretty helpful.
function createForm() {
    let oldForm = document.getElementById('recipeForm');
    if (oldForm) {
        oldForm.remove();
    }

    let recipeForm = document.createElement('form');
    recipeForm.id = "recipeForm";

    let recipeInput = document.createElement('input');
    recipeInput.type = 'text';
    recipeInput.placeholder = 'Please enter a recipe name!';
    recipeInput.id = 'newRecipe';
    recipeForm.appendChild(recipeInput);

    let ratingInput = document.createElement('input');
    ratingInput.type = 'text';
    ratingInput.placeholder = 'Please enter a rating!';
    ratingInput.id = 'newRating';
    recipeForm.appendChild(ratingInput);

    let submitButton = document.createElement('button');
    submitButton.textContent = 'Submit';
    recipeForm.appendChild(submitButton);

    recipeForm.addEventListener('submit', async function (e) {
        e.preventDefault();
    
        let currentDate = new Date();
        //I kept on getting my date in a format with miliseconds and I forgot how to do the rounding thing with dates so I googled it and came up with this.
        let formattedDate = currentDate.toISOString().split('T')[0];
    
        let recipe = {
            recipeName: e.target.elements.newRecipe.value,
            recipeRating: e.target.elements.newRating.value,
            recipeDateEntered: formattedDate,
            isFavorited: false,
            isDeleted: false
        };
    
        const response = await fetch('http://localhost:5000/api/recipe', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(recipe)
        });
        //This whole response error handling thing was made when I was pulling out my hair. I can't get rid of it. I know you should keep code like well handled and commented but I feel like its unnecessary since a recipe will never not have an ID if its properly generated.
        //That being said, when I don't have this everything breaks. Im so sorry.
        if (response.ok) {
            const newRecipe = await response.json();
                        
            if (newRecipe.recipeId) {
                newRecipe.RecipeId = newRecipe.recipeId;
                recipes.push(newRecipe);
                addRow(newRecipe);
                refreshTable();
            } else {
                console.error("New recipe does not have a recipeId:", newRecipe);
            }
        } else {
            console.error("Failed to add recipe:", response.statusText);
        }
    });

    app.appendChild(recipeForm);
}

//Also pretty simple. It adds rows to the table with a couple error catches
function addRow(recipe) {
    let tableBody = document.getElementById('recipeTableBody');
    let tr = document.createElement('TR');
    tableBody.appendChild(tr);

    let td1 = document.createElement('TD');
    td1.width = 200;
    td1.appendChild(document.createTextNode(recipe.recipeName));
    tr.appendChild(td1);

    let td2 = document.createElement('TD');
    td2.width = 60;
    td2.appendChild(document.createTextNode(recipe.recipeRating));
    tr.appendChild(td2);

    let td3 = document.createElement('TD');
    td3.width = 120;

    let formattedDate = new Date(recipe.recipeDateEntered).toLocaleDateString();
    td3.appendChild(document.createTextNode(formattedDate));
    tr.appendChild(td3);

    let td4 = document.createElement('TD');
    td4.width = 120;
    td4.appendChild(document.createTextNode(recipe.isFavorited.toString()));
    tr.appendChild(td4);

    let td5 = document.createElement('TD');
    td5.width = 120;

    let favoriteButton = document.createElement('button');
    favoriteButton.textContent = recipe.isFavorited ? 'Unfavorite' : 'Favorite';
    td5.appendChild(favoriteButton);

    let deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    td5.appendChild(deleteButton);

    favoriteButton.addEventListener('click', async function () {
        recipe.isFavorited = !recipe.isFavorited;
            localStorage.setItem('myRecipes', JSON.stringify(recipes));
            refreshTable();
    });

    deleteButton.addEventListener('click', async function () {
        const response = await fetch(`http://localhost:5000/api/recipe/${recipe.RecipeId}`, {
            method: 'DELETE'
        });
            recipe.isDeleted = true;
            localStorage.setItem('myRecipes', JSON.stringify(recipes));
            refreshTable();

    });

    tr.appendChild(td5);
}
//The funciton called by handleonload and refresh table. It creates the table itself, and notably obliterates the table before it so that it completely refreshes it.
//I'm positive theres a more efficient way to do that but so far it alludes me.
function createTable() {
    let oldTable = document.getElementById('recipeTable');
    if (oldTable) {
        oldTable.remove();
    }

    let table = document.createElement('TABLE');
    table.border = '1';
    table.id = 'recipeTable';
    let tableBody = document.createElement('TBODY');
    tableBody.id = 'recipeTableBody';
    table.appendChild(tableBody);

    let tr = document.createElement('TR');
    tableBody.appendChild(tr);

    let th1 = document.createElement('TH');
    th1.width = 200;
    th1.appendChild(document.createTextNode('Recipe'));
    tr.appendChild(th1);

    let th2 = document.createElement('TH');
    th2.width = 60;
    th2.appendChild(document.createTextNode('Rating'));
    tr.appendChild(th2);

    let th3 = document.createElement('TH');
    th3.width = 120;
    th3.appendChild(document.createTextNode('Date Entered'));
    tr.appendChild(th3);

    let th4 = document.createElement('TH');
    th4.width = 120;
    th4.appendChild(document.createTextNode('Is Favorited'));
    tr.appendChild(th4);

    let th5 = document.createElement('TH');
    th5.width = 120;
    th5.appendChild(document.createTextNode('Actions'));
    tr.appendChild(th5);

    app.appendChild(table);

    //Simple filter to first check and see if a recipe is deleted (in which it will not show it) and then one to sort via rating every refresh.
    recipes
        .filter(recipe => !recipe.isDeleted)
        .sort((a, b) => parseFloat(b.recipeRating) - parseFloat(a.recipeRating))
        .forEach((recipe) => {
            addRow(recipe);
        });
}

//As mentioned with handleonload and the createtable, this is so that I can have a properly oriented table with the createtable always above the form.
function refreshTable() {
    createTable();
    createForm();
}

handleOnLoad();
